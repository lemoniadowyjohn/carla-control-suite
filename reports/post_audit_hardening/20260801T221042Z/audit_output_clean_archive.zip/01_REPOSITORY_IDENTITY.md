# Repository Identity — Phase 0 Record

| Field | Value |
|---|---|
| Repository root | `C:\Users\admin\PycharmProjects\gpt4\pythonProject3\carla_-main` |
| Current branch | `integration/governed-map-quality-20260729` |
| Current commit | `dac6930a7de1698c4b2a1fe4cfb6deb7f2679fe2` |
| Upstream | `https://github.com/lemoniadowyjohn/carla-control-suite.git` (origin) |
| Ahead/behind | 0/0 vs `origin/integration/governed-map-quality-20260729` |
| Dirty state | 17 untracked/working files (audit_output/, carla_governed/, external/, reports/, nul, vehicle.) |
| Worktrees | `carla_-main` (dac6930a), `carla_main_audit` (d202ad22), `carla_main_governed` (deb261bf) + sub-worktrees, `carla_rr_recovery` (25917b18) |
| Submodules | none |
| Git LFS | active; 4 objects: raw_xodr_run_1.xodr (6044a87d8d), raw_xodr_run_1_epsg32632_header_pinned.xodr (ff2a05e7b0), raw_xodr_run_2.xodr (c8c57c7282), ingolstadt_authoritative.osm (b9e074656f) |
| Selected release profile | FULL_PRODUCTION_RELEASE (campaign `ingolstadt_cooked_perception_v1`) |
| Effective configuration hash | not established (no canonical snapshot; REP-007/BOOT-004 unverified) |
| Authoritative OSM hash | `b9e074656f744c31e6aabb0a16e6b2246824ca74e202ea2c316ff7f22364f24f` |
| Authoritative XODR hash | `ff2a05e7b00b8fc1bde38f569413223c03a4f4ac9c31eceb5a8592df47d0d17d` |
| Authoritative FBX/tile hashes | none exist at this commit |
| Candidate output hash | none; readiness `CRS_CONTRACT_READY_STRUCTURAL_UNREVIEWED` |
| CARLA version | wheel 0.9.16 importable; server unreachable (127.0.0.1:2000 refused); runtime version UNVERIFIED |
| Unreal version | unavailable (BLOCKED_TOOLCHAIN) |
| Python environment | 3.12.2; `.venv`; 159 packages; pip 26.0 |

## Notes
- The earlier session assumption "`import carla` fails" was **corrected** during this audit: the 0.9.16 wheel imports successfully; the blocker is the absent server.
- CARLA runtime evidence, Unreal cooking evidence and exact-map loading cannot be produced on this host; affected requirements are BLOCKED.
- The audited root tree does not import end-to-end (SYS-001); behavior lives in `submission\infrastructure\ultimate_pipeline`.
