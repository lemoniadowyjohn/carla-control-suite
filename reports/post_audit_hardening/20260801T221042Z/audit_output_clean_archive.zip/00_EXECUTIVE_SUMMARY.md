# Low-Cost Model Audit — Executive Summary

**Repository Root:** `C:\Users\admin\PycharmProjects\gpt4\pythonProject3\carla_-main`
**Current Branch:** `integration/governed-map-quality-20260729`
**Current Commit:** `dac6930a7de1698c4b2a1fe4cfb6deb7f2679fe2`
**Upstream:** `origin/integration/governed-map-quality-20260729` (0/0 ahead/behind)
**Date:** 2026-08-01
**Audit ID:** `LOW_COST_MODEL_AUDIT_20260801`

---

## 1. Scope & Totals

- **Requirements expected:** 218 (spec claims 232 = 218 requirement IDs + 14 issue IDs REP-I01..I04, OSM-I01..I04, ENR-I01..I06; SHA-256 false positive excluded)
- **Requirements assessed:** 218
- **Missing requirement IDs:** 0
- **Duplicate requirement IDs:** 0
- **Unknown requirement IDs:** 0
- **UNASSESSED:** 0
- **NOT_TESTED:** 0

### Verification State Breakdown

| Status | Count |
|---|---|
| **PASS** | 45 |
| **FAIL** | 50 |
| **BLOCKED** | 22 |
| **INSUFFICIENT_EVIDENCE** | 85 |
| **CONFLICTING_EVIDENCE** | 15 |
| **NOT_TESTED** | 0 |
| **NOT_APPLICABLE** | 1 |
| **TOTAL** | **218** |

### Implementation State Breakdown

| State | Count |
|---|---|
| VERIFIED_ACTIVE | 57 |
| IMPLEMENTED_INACTIVE | 28 |
| IMPLEMENTED_UNVERIFIED | 6 |
| PARTIAL | 83 |
| MISSING | 42 |
| NOT_APPLICABLE | 2 |

---

## 2. Authoritative Artifact Hashes

- **Authoritative OSM:** `b9e074656f744c31e6aabb0a16e6b2246824ca74e202ea2c316ff7f22364f24f` (`campaigns/ingolstadt_cooked_perception_v1/source/ingolstadt_authoritative.osm`)
- **Authoritative Candidate XODR:** `ff2a05e7b00b8fc1bde38f569413223c03a4f4ac9c31eceb5a8592df47d0d17d` (`campaigns/ingolstadt_cooked_perception_v1/candidate/raw_xodr_run_1_epsg32632_header_pinned.xodr`, 32710 roads / 3646 junctions / signal_count=0 / flat zero elevation)
- **Authoritative FBX/tile hashes:** none established — no cooked/tiled artifacts exist at this commit
- **Candidate output hash:** no final candidate produced; readiness `CRS_CONTRACT_READY_STRUCTURAL_UNREVIEWED`
- **CARLA version:** wheel 0.9.16 present and importable (`import carla` OK); NO server reachable on localhost:2000; runtime version UNVERIFIED
- **Unreal version:** unavailable (BLOCKED_TOOLCHAIN — no UE4.26 source build, packaged E:\CARLA\CARLA_0.9.16 cannot cook)
- **Python environment:** 3.12.2, `.venv` (159 packages)

---

## 3. Profile Release Matrix

| Release Profile | Verdict | Highest Maturity Reached | Primary Blocker |
|---|---|---|---|
| **STANDALONE_XODR** | **BLOCKED** | `FULL_MAP_OFFLINE` | 40 FAIL + 10 BLOCKED incl. tiling (TIL-001..006,009), TOP-001 dangling links, LLK, SAN inactive stage, ENR/SIG missing |
| **COOKED_VISUAL_MAP** | **BLOCKED** | `FULL_MAP_OFFLINE` | STANDALONE blockers + Unreal/B4 toolchain + BLD-001..007 + O2W-003/004 missing |
| **PERCEPTION_READY** | **BLOCKED** | `FULL_MAP_OFFLINE` | COOKED blockers + no CARLA server + SEN-003/004/005/006 + PER-002/003/004/005/006/007 |
| **DOMAIN_GAP_ONLY** | **BLOCKED** | `FULL_MAP_OFFLINE` | DG-001/002/005 CONFLICTING + FIN-002 + no generated-map route data |
| **FULL_PRODUCTION_RELEASE** | **BLOCKED** | `FULL_MAP_OFFLINE` | union of all above; 50 FAIL / 22 BLOCKED / 15 CONFLICTING |

---

## 4. Top Blocking Issues

1. **Root release tree is a stripped, non-importable skeleton (SYS-001).** `ultimate_pipeline/main_pipeline.py` raises `ModuleNotFoundError: ultimate_pipeline.bootstrap_repo_root`; ~20 referenced modules absent; all audited behavior lives only in `submission\infrastructure\ultimate_pipeline`. No policy declares the release tree.
2. **CARLA runtime unavailable.** No server on localhost:2000; Unreal cooking BLOCKED_TOOLCHAIN. 22 requirements BLOCKED; CAR-001..011 runtime evidence impossible.
3. **Signals/controllers entirely absent.** Pipeline emits traffic lights as `<object>`; signal_count=0; SIG-001..005 MISSING/FAIL. Enrichment writers are non-idempotent (traffic lights duplicated on rerun).
4. **Tiling fails 7 of 9 requirements.** Road bounds ignore curve extrema; junctions cut at tile boundaries; duplicated roads not byte-identical; `UP_ALLOW_TILE_QA_FAIL=1` set by default in `run_full_test.py`.
5. **Elevation profile fitting missing (ELV-002/005) and seam fixer is a docstring stub (ELV-009).**
6. **LaneLinks: sanitizer is a stub returning unconditional 'ok' (LLK-007); junction laneLinks regenerated unconditionally (LLK-001).**
7. **TOP-001 FAIL:** authoritative candidate contains 656 dangling road-level links.
8. **Roundabout subsystem MISSING** (RAB-001..004,006): detection not in live tree, reconstruction disabled by default.
9. **Blender/OSM2World pipeline missing** (BLD-001..007, O2W-003/004): no FBX re-import, no OBJ validation, ambiguous `scene.fbx` naming.
10. **Perception depth modality missing** (PER-002) and no split/leakage checker (PER-005).

---

## 5. Conclusion & Handoff

No release profile is releasable at commit `dac6930a`. The pipeline's governance/coordinate/freeze contracts (GATE-001..007, FRZ-004, GEO-008) hold at unit level, and 45 requirements PASS with executable evidence, but the mandatory gates for every profile are blocked by missing runtime/toolchain dependencies and by confirmed implementation gaps (signals, tiling, elevation fitting, lane links, roundabouts, visual asset pipeline). The audited root tree must first be made importable and the release tree declared before any promotion can be considered.
