# Contradictions

Contradictions are requirement-vs-implementation, requirement-vs-evidence, or implementation-vs-implementation conflicts that remain unresolved. Do not resolve by majority vote; each CONFLICTING_EVIDENCE record requires resolution before the profile can pass.

## CONFLICTING_EVIDENCE — 15

- **DEM-005**: PARTIAL with CONFLICTING_EVIDENCE: flat/median/hardcoded fallbacks are fail-closed in strict (release) mode, but the KD-tree nearest-neighbor extrapolation (<=2000m) is an active distant-nearest-neighbor fallback in release mode, violating DEM-005 literally. BLOCKS_PROFILE until the extrapolation is gated out in release mode.
  - Requirement DEM-005 forbids global median/hardcoded/distant nearest-neighbor fallback in release mode. Implementation: KD-tree nearest-neighbor extrapolation (max 2000m, env-tunable) and graph propagation run unconditionally before the strict-mode abort, so release mode still uses distant nearest-neighbor fallback. Median/hardcoded paths exist but are blocked by the strict raise; they would fire in non-strict mode. Flat fallback is blocked by FAIL_ON_FLAT_ELEVATION=True via _flat_sampler_or_raise.
- **DG-001**: PASS with limitation: release vs working artifact hash separation is implemented and verified for the release pack; no code-level enforcement exists, and the cited run_03 source is missing locally.
  - run_11_audit_addendum.json cites run_03/auto_aligned_hardened.xodr as the authoritative numeric source, but that file does not exist in this worktree.
- **DG-002**: PASS as documented practice: submitted run_11 measurements are not replaced and their boundaries are stated (incl. unsupported claims list); no code enforcement exists.
  - generate_gap_figures.py docstring says it patches full_report.json (removes 'ICP refinement' label, adds alignment_method_note) - a mutation of the release report, undermining immutability of submitted-thesis measurements.
- **DG-005**: PASS as documentation: run_11 evidence explicitly separates coverage/scope (4.9x auto length, 0.046 bbox IoU) from defect claims; no code-level enforcement.
  - full_report.json reports bbox_iou_after_reprojection=0.6369 without the coverage caveat that the addendum attaches.
- **ELV-006**: PARTIAL: solver preserves slopes by construction but lacks DEM-residual and max-shift constraints and auto-enables in strict mode.
  - Requirement says offset solving must not shift entire roads away from DEM without residual/grade constraints. Solver preserves grades (b/c/d untouched) but has no DEM-residual constraint and no max-shift bound per road; strict mode auto-enables it.
- **ENR-002**: PARTIAL/CONFLICTING_EVIDENCE: unmatched OSM data is correctly left unresolved by the three OSM-meta writers, but realism/TL/object-injection paths infer or guess from heuristics without any unresolved-flag or confidence marker.
  - Grounded writers comply (no guess); heuristic modules (realism speed signs, TL inference, nearest-road fallback) guess without marking content as unresolved/inferred.
- **FIN-002**: PASS for artifact-hash verification with limitation: report files are not hashed/verified as part of promotion; signature.json is produced but not consumed.
  - Requirement says all report hashes verified before promotion; only the artifact is verified by the transaction.
- **JCT-006**: Deep-copy + revert exists for planView and the blocked path preserves the original; atomic commit is partial (planView scope only).
  - Requirement demands deep copy of the complete road; implementation copies only the planView element.
- **JCT-008**: Numeric before/after evidence and unresolved marking are implemented and unit-tested; the before/after overlay portion is missing.
  - Requirement asks for before/after overlay; only numeric evidence exists.
- **LAN-001**: PARTIAL: s-ordering is consistently applied; duplicate-s detection and [0,length] coverage validation are absent; pinned artifact trivially passes.
  - Ordering is enforced in consumers; uniqueness and coverage are not enforced anywhere.
- **LLK-001**: CONFLICTING_EVIDENCE/FAIL in runnable copy: submission stage_08 regenerates all junction laneLinks unconditionally, violating 'preserve existing valid LaneLinks until a complete replacement candidate passes'. ROOT copy is compliant but un-runnable. BLOCKS_PROFILE.
  - 1) ROOT guarded vs SUBMISSION unguarded stage_08 (sha256 differ). 2) docs/hardening/03_hardening_proof.md claims AND-policy gating (LaneLink regen False by default) but the submission copy is not gated. 3) LaneLinkBuilder wipes old laneLinks before building - no 'replacement candidate must pass' validation exists.
- **SAN-007**: The sanitizer API writes a separate output and never overwrites raw input (executed), but no active stage or campaign artifact produces 01_sanitized.xodr at HEAD.
- **SEN-001**: PASS at artifact level: exactly one calib file, hash verified, tracked, parseable, used by the single calibration path. BLOCKS_PROFILE because the root default path is broken and required metadata fields are absent.
  - Hash stable and file tracked, but default-path resolution differs between root and submission settings.py copies.
- **SIG-002**: PASS (vacuously, low confidence): visible traffic-light <object>s are non-functional (dynamic='no') and no code counts them as functional traffic control; pinned artifact contains none.
  - None material; reporting ambiguity noted.
- **TQA-004**: PARTIAL/PASS on covered classes: drivable-surface hole/seam/drop/dead-connection scan is active and clean on the pinned artifact (0 issues, 32710 roads); junction-blob/roundabout-chord/lane-marking/signal/terrain/object classes lack scanners.
  - Offline coverage is real but partial relative to the defect-class breadth implied by the requirement.

## Systemic Finding SYS-001 (reviewer_B)

- **Release-tree contradiction:** all audited behavior lives only in `submission\infrastructure\ultimate_pipeline`; the root `ultimate_pipeline\main_pipeline.py` is a stripped skeleton that cannot import (`ModuleNotFoundError: ultimate_pipeline.bootstrap_repo_root`, ~20 missing modules), and `pipeline_stages\stage_01_sanitize.py` / `stage_02_topology_semantics.py` do not exist at HEAD. No policy declares the release tree; every pipeline-integration claim is unexecutable from the audited root.