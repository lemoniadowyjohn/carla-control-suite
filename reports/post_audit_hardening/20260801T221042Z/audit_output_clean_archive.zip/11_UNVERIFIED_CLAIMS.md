# Unverified Claims

Claims found in repository reports, manifests, and documentation that could NOT be verified with current executable evidence at commit dac6930a:

## From reports/
- `reports\C01_carla_runtime_audit.json` (2026-07-29 @ ff00099d): claims runtime audit results incl. 'source_files_present: false' — contradicted by files now present under `submission\infrastructure\ultimate_pipeline\carla_tools`; report-only, stale commit, not executable evidence
- `reports\source_visual_closure\final_gate_status.md`: `B2_B3_CLOSED_B4_BLOCKED` — B4 toolchain blocked; visual closure claims not verifiable on this host
- `reports\new_campaign\C55V01a_raw_xodr.json`: converter donor sha `6b250621` — from `carla_main_governed` worktree, different commit; not current-branch evidence
- `reports\new_campaign\DSV14_cleanup.md`: historical; not current evidence

## From campaigns/
- `manifest.json`: `readiness_state = CRS_CONTRACT_READY_STRUCTURAL_UNREVIEWED`; `carla_osm2odr_version = UNKNOWN_UNSOURCED`; `real_map_mutation_authorized = false`
- Raw converter outputs preserved (run_1, run_2, pinned) with verified hashes, but conversion version is UNKNOWN_UNSOURCED

## Claims contradicted by this audit
- XODR `signal_count=0` is treated as a result of the pipeline; enrichment never ran on the pinned artifact (writers would have had 529 traffic_sign ways and 4350 maxspeed ways)
- Any claim that root `ultimate_pipeline` is the production tree (SYS-001: it cannot import)
- FIN-010: FV09 report states highest maturity + blocked levels but was generated on an older branch