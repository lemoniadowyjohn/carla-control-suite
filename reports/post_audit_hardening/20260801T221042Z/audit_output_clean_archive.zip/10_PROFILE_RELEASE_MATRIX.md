# Profile Release Matrix

| Release Profile | Verdict | Highest Maturity Reached | PASS | FAIL | BLOCKED | CONFLICTING | INSUFFICIENT | Top Blockers |
|---|---|---|---|---|---|---|---|---|
| **STANDALONE_XODR** | **BLOCKED** | `FULL_MAP_OFFLINE` | 44 | 40 | 10 | 14 | 71 | BOOT-001, ELV-002, ELV-005, ELV-009, ENR-001 |
| **COOKED_VISUAL_MAP** | **BLOCKED** | `FULL_MAP_OFFLINE` | 45 | 48 | 19 | 14 | 76 | BLD-001, BLD-002, BLD-003, BLD-004, BLD-005 |
| **PERCEPTION_READY** | **BLOCKED** | `FULL_MAP_OFFLINE` | 45 | 50 | 22 | 15 | 85 | BLD-001, BLD-002, BLD-003, BLD-004, BLD-005 |
| **DOMAIN_GAP_ONLY** | **BLOCKED** | `FULL_MAP_OFFLINE` | 20 | 2 | 2 | 4 | 27 | BOOT-001, REP-004, REP-001, REP-002, DG-001 |
| **FULL_PRODUCTION_RELEASE** | **BLOCKED** | `FULL_MAP_OFFLINE` | 45 | 50 | 22 | 15 | 85 | BLD-001, BLD-002, BLD-003, BLD-004, BLD-005 |

A profile is PASS only when every mandatory requirement for that profile is PASS. No averaging; no confidence overrides a failed mandatory gate.