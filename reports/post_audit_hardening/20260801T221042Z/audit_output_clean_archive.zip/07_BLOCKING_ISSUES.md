# Blocking Issues

## FAIL — 50 (requirement not met at audited commit)

- **BLD-001** (NON_BLOCKING): PARTIAL/FAIL: version/hash/log recording exists (partial), but script hash, import/export options, coordinate transforms, and units are not recorded; coordinate_contract detects the gap but the runner cannot fill it.
- **BLD-002** (NON_BLOCKING): MISSING/FAIL: no preservation/transformation accounting for hierarchy, names, materials, textures, UVs, normals, or bounds exists in the Blender runner.
- **BLD-003** (NON_BLOCKING): MISSING/FAIL: no axis/handedness/scale/origin/XODR-alignment validation using control points exists in the Blender path.
- **BLD-004** (NON_BLOCKING): MISSING/FAIL: no splitting of meshes into CARLA semantic categories or stable names in the Blender/FBX path.
- **BLD-005** (NON_BLOCKING): PARTIAL/FAIL: only a disabled-by-default road-geometry diagnostic exists; no FBX collision-mesh generation or LOD handling; validator returns PASS-by-default and cannot gate releases.
- **BLD-006** (NON_BLOCKING): MISSING/FAIL: no FBX re-import verification step exists in the Blender runner; execution also blocked by missing toolchain.
- **BLD-007** (NON_BLOCKING): MISSING/FAIL: Blender/OSM2World output naming is the ambiguous generic 'scene.fbx'/'scene.obj'; the campaign's own manifest rejected the resulting artifact for provenance reasons.
- **BOOT-001** (NON_BLOCKING): Register exists and is well-formed but omits required origin and acquisition date fields.
- **CAR-011** (BLOCKS_PROFILE): FAIL: route completion is not verified (movement-only smoke), lane-invasion detection is absent, and spawn existence is recorded as drivability in both stage_08 copies. BLOCKS_PROFILE for the drivability claim.
- **ELV-002** (BLOCKS_PROFILE): MISSING: no piecewise vertical profile fitting exists; every road gets exactly one elevation segment. BLOCKS_PROFILE for the DEM-enabled profile.
- **ELV-005** (BLOCKS_PROFILE): MISSING: no separation of terrain-following roads from structures in the elevation path. BLOCKS_PROFILE for the DEM-enabled profile.
- **ELV-009** (BLOCKS_PROFILE): FAIL: the dedicated seam fixer is a docstring-only stub, unreferenced by the pipeline; it must be implemented or removed from claims. Seam DETECTION (gate_elevation_seams) is real, but seam FIXING is absent.
- **ENR-001** (BLOCKS_PROFILE): MISSING/FAIL: no enrichment writer records OSM source entity, mapping confidence, or affected XODR element in output; verified by execution probe and repo-wide grep.
- **ENR-003** (BLOCKS_PROFILE): PARTIAL/FAIL: enrichment is not globally idempotent - repeated runs duplicate traffic lights and regulatory-sign objects with colliding ids; only speed/turn-lane writers are duplicate-safe.
- **ENR-004** (BLOCKS_PROFILE): MISSING/FAIL: no grounded/inferred/synthetic-debug mode separation exists; enrichment toggles write into a single artifact with no provenance distinction.
- **ENR-005** (BLOCKS_PROFILE): PARTIAL/FAIL: only inserted counts (and ways_indexed) are reported; requested/matched/updated/rejected/ambiguous tallies do not exist.
- **FRZ-002** (BLOCKS_ALL_RELEASES): Fingerprint comparison is implemented but is self-inconsistent by construction and cannot execute in this checkout; the gate is effectively a no-op (attribute-presence check only, mismatch non-raising). Requirement FAILS.
- **GEO-010** (BLOCKS_PROFILE): Quarantine implementation is not present in the live tree; the import is broken by construction. Release-mode quarantine requirement cannot be met in this checkout.
- **JCT-003** (NON_BLOCKING): No lane-center alignment implementation found; connectors are fitted to road reference-line endpoints only. Requirement not met.
- **JCT-004** (NON_BLOCKING): No validation that rebuilt connectors avoid self-intersection, unrelated roads, or roundabout islands. Requirement not met.
- **JCT-007** (NON_BLOCKING): No invalidation/remapping of lane sections, offsets, elevation, superelevation, crossfall, signals, or objects on connector length change. Requirement not met.
- **LLK-003** (BLOCKS_PROFILE): PARTIAL/FAIL: connecting lanes resolve via contactPoint, incoming lanes use fixed last-section assumption.
- **LLK-004** (BLOCKS_PROFILE): PARTIAL/FAIL: pairing uses side+sign ordering with type/width filters; no geometry or movement-intent criteria.
- **LLK-006** (BLOCKS_PROFILE): MISSING: no laneLink path crossing/containment validation exists. BLOCKS_PROFILE for the junction-topology claim.
- **LLK-007** (BLOCKS_PROFILE): FAIL: laneLink sanitizer is a stub returning unconditional 'ok'; it is wired into both stage_08 copies and its output is persisted as evidence.
- **OSM-001** (BLOCKS_PROFILE): OSM acquisition/validation module layer is entirely absent from the audited commit; entrypoint cannot import. Requirement unmet.
- **OSM-003** (BLOCKS_PROFILE): No canonical Osm2OdrSettings exists anywhere in the audited tree; entry points cannot share a canonical configuration because the converter module is absent.
- **OSM-006** (BLOCKS_PROFILE): No durable OSM-to-XODR provenance mapping exists at the audited commit.
- **PER-002** (BLOCKS_PROFILE): FAIL: depth modality missing; RGB/semseg/LiDAR present but unverified. BLOCKS_PROFILE.
- **RAB-001** (BLOCKS_PROFILE): Roundabout detection logic is not present in the live tree; reconstruction is disabled by default and untested. Requirement not met in this checkout.
- **RAB-002** (BLOCKS_PROFILE): Ring construction/orientation is submission-only and untested. Requirement not met in this checkout.
- **RAB-003** (BLOCKS_PROFILE): Island/chord avoidance is not present in the live tree and untested. Requirement not met.
- **RAB-004** (BLOCKS_PROFILE): Entry/exit reachability is not present in the live tree and untested. Requirement not met.
- **REP-004** (BLOCKS_ALL_RELEASES): Not all production modules import; core pipeline module is broken.
- **SEM-003** (BLOCKS_PROFILE): Road classification semantics are not implemented in the audited canonical tree.
- **SEM-006** (NON_BLOCKING): SUMO/netconvert element-by-element provenance comparison is not implemented; SUMO is not currently used by the audited pipeline.
- **SEN-003** (BLOCKS_PROFILE): FAIL: intrinsics (K/K_undist/D), extrinsics (cTv/vTl), attachment pose and resolution ARE recorded and parseable, but sensor_tick, FOV and blueprint attributes are missing from the required record set.
- **SIG-001** (BLOCKS_PROFILE): MISSING/FAIL: the pipeline never emits native <signal>/<signalReference>/<controller>/<control> structures; traffic lights and signs are written as static <object> elements.
- **SIG-003** (BLOCKS_PROFILE): MISSING/FAIL: signals are never placed with validated s/t/zOffset/hOffset or lane-validity ranges; no <validity> is emitted.
- **SIG-004** (BLOCKS_PROFILE): MISSING/FAIL: no signal/controller layer exists to survive later stages; no preservation or tiling tests exist. CARLA runtime verification additionally blocked (no server, no carla import).
- **SIG-005** (BLOCKS_PROFILE): MISSING/FAIL: no source-ID or spatial-grouping duplicate detection exists near junctions; repeated enrichment provably duplicates traffic-light objects.
- **TIL-001** (BLOCKS_PROFILE): FAIL: road bounds are computed from geometry start points only; curve extrema (arc/spiral/paramPoly3) are ignored, producing truncation/overshoot artifacts at tile seams.
- **TIL-002** (BLOCKS_PROFILE): FAIL: complete roads are cloned whole, but the documented policy is absent and required junction context is not assigned to tiles.
- **TIL-003** (BLOCKS_PROFILE): FAIL: road-contained elements (signals, objects, markings, profiles, lane links) are preserved, but junction IDs and controllers are not, so preservation is incomplete.
- **TIL-004** (BLOCKS_PROFILE): FAIL: duplication is inherent to the observation-window design; copies are not byte-identical (per-tile marker attributes) and no ownership metadata is emitted.
- **TIL-005** (BLOCKS_PROFILE): FAIL: no mechanism prevents cutting junctions/connectors at tile boundaries; junctions are absent from tiles entirely.
- **TIL-006** (NON_BLOCKING): PARTIAL: adjacency graph generation and an offline geometric gap evaluator exist and their unit tests pass, but border-connection verification is approximate (straight-line only) and not enforced in the tiling stage.
- **TIL-009** (BLOCKS_PROFILE): FAIL: release-mode tile-failure blocking is not enforced; the primary runner enables UP_ALLOW_TILE_QA_FAIL by default and the release-profile flag is dead configuration.
- **TOP-001** (BLOCKS_PROFILE): The authoritative candidate contains 656 dangling road-level links, so the property does not hold on current artifacts; the in-tree repair (TopologyRepair) removes such refs when invoked but no stage invokes it at HEAD.
- **TOP-006** (NON_BLOCKING): The required component-count guard is not implemented; only an unreachable component counter exists.

## BLOCKED — 22 (required dependency/toolchain/artifact unavailable)

- **CAR-001** (BLOCKS_PROFILE): PARTIAL/BLOCKED: loader and version-recording are present and offline-importable; exact-load enforcement is record-only and runtime evidence is impossible in this environment.
- **CAR-004** (BLOCKS_PROFILE): PARTIAL/BLOCKED: spawn-point existence checks exist; drivability-from-spawn is not verified by the gate and runtime evidence is impossible here.
- **CAR-005** (BLOCKS_PROFILE): MISSING/BLOCKED: no road-class/distributed spawn-point generator and no 500-tick budget exist; runtime evidence also impossible.
- **CAR-006** (BLOCKS_PROFILE): IMPLEMENTED_INACTIVE/BLOCKED: tile-scoped actor management exists in source; cannot be executed or proven without a server.
- **CAR-007** (BLOCKS_PROFILE): IMPLEMENTED_INACTIVE/BLOCKED: camera/ego setup logic present; requires live CARLA to confirm 'camera on road surface with visible vehicle'.
- **CAR-008** (BLOCKS_PROFILE): PARTIAL/BLOCKED: spawner-level seeding is implemented and defaulted to seed 0 when enabled; TM random choice and end-to-end determinism unverifiable without a server.
- **CAR-009** (BLOCKS_PROFILE): VERIFIED_ACTIVE (source-level): comprehensive defensive cleanup exists; end-to-end teardown verification requires a server.
- **LAN-011** (NON_BLOCKING): MISSING: no junction-mouth width bound or connector-width compatibility check exists; verification BLOCKED (no CARLA, no offline checker).
- **LLK-008** (BLOCKS_ALL_RELEASES): BLOCKED: CARLA junction-movement confirmation cannot be executed in this environment (no server, no carla import). Releases requiring CARLA-confirmed junction/roundabout evidence cannot be verified.
- **O2W-003** (NON_BLOCKING): MISSING: no structural OBJ validation (vertices/faces/bounds) exists; only suffix+existence checks; no artifact to verify.
- **O2W-004** (NON_BLOCKING): MISSING: no OBJ<->XODR alignment verification exists and no artifact is available to verify; BLOCKED on both axes.
- **PREF-002** (BLOCKS_PROFILE): CARLA version/compatibility probe implemented but inactive; cannot be executed.
- **PREF-003** (BLOCKS_PROFILE): Port/process/shutdown verification implemented in snapshot only; execution blocked by missing CARLA.
- **RAB-005** (BLOCKS_ALL_RELEASES): CARLA route evidence is impossible in this environment; no roundabout roads exist in the pinned artifact. Verification BLOCKED.
- **REP-001** (BLOCKS_ALL_RELEASES): No single canonical production entry point; entrypoint ambiguity blocks release.
- **REP-002** (BLOCKS_ALL_RELEASES): Import cycle not isolated; main_pipeline cannot import at all.
- **SEN-004** (NON_BLOCKING): IMPLEMENTED_UNVERIFIED: sync-mode machinery exists and is deferred correctly on paper; single-tick-owner exclusivity unenforced and runtime verification BLOCKED.
- **SEN-005** (BLOCKS_PROFILE): PARTIAL/BLOCKED: RGB + semseg + LiDAR machinery present (runtime-unverified); depth collection does not exist -> BLOCKS_PROFILE.
- **SEN-006** (NON_BLOCKING): IMPLEMENTED_UNVERIFIED: wait-for-first-sample helper unit-tested (PASS); live callback stability and frame-count verification BLOCKED.
- **TIL-008** (NON_BLOCKING): PASS (design): tile checks run on the actual emitted tile files; offline execution is BLOCKED_TOOLCHAIN due to CARLA unavailability.
- **TQA-005** (NON_BLOCKING): IMPLEMENTED_INACTIVE/BLOCKED: stress tester and weather controller exist but are default-off, simulation-gated off, weather-unwired, and unverifiable without CARLA.
- **TQA-006** (NON_BLOCKING): IMPLEMENTED_INACTIVE: SeamRepair is dead code (zero callers); neither repaired tiles nor explicit no-repair reports are produced.

## BLOCKS_ALL_RELEASES (6)

- **FRZ-002** [FAIL]: Fingerprint comparison is implemented but is self-inconsistent by construction and cannot execute in this checkout; the gate is effectively a no-op (attribute-presence check only, mismatch non-raising). Requirement FAILS.
- **LLK-008** [BLOCKED]: BLOCKED: CARLA junction-movement confirmation cannot be executed in this environment (no server, no carla import). Releases requiring CARLA-confirmed junction/roundabout evidence cannot be verified.
- **RAB-005** [BLOCKED]: CARLA route evidence is impossible in this environment; no roundabout roads exist in the pinned artifact. Verification BLOCKED.
- **REP-001** [BLOCKED]: No single canonical production entry point; entrypoint ambiguity blocks release.
- **REP-002** [BLOCKED]: Import cycle not isolated; main_pipeline cannot import at all.
- **REP-004** [FAIL]: Not all production modules import; core pipeline module is broken.
---

# Strengthening List — Issues Requiring Remediation to Improve Map Quality

This document consolidates every issue identified across the compliance audit (Phases 0-8), the adversarial review (Phase 6), and the pipeline quality audit into a single prioritized strengthening list. Each item includes the requirement ID, current status, and the specific action needed.

---

## P0 — Release-Blocking (no profile can pass without these)

| # | ID | Current Status | Issue | Required Action |
|---|---|---|---|---|
| 1 | SYS-001 | FAIL | Root `ultimate_pipeline/main_pipeline.py` cannot import (~20 missing modules). All pipeline behavior lives only in `submission/infrastructure/`. No release tree is declared. | Declare the release tree. Make `ultimate_pipeline/main_pipeline.py` importable end-to-end. Either move the active code to the root tree or create a proper re-export/shim layer. |
| 2 | SIG-001 | MISSING/FAIL | Pipeline never emits native `<signal>/<signalReference>/<controller>/<control>` structures. signal_count=0 on the pinned artifact. | Implement a signal layer that emits native XODR signal structures from OSM traffic signals. |
| 3 | SIG-003 | MISSING/FAIL | Signals are never placed with validated `s,t,zOffset,hOffset` or lane-validity ranges. | Implement signal placement with validated s/t/zOffset/hOffset and lane-validity range checks. |
| 4 | SIG-004 | MISSING/FAIL | No signal/controller layer exists to survive later stages, tiling, and lightening. | Implement a signal/controller preservation layer that survives tiling, lightening, and all downstream stages. |
| 5 | SIG-005 | MISSING/FAIL | No source-ID or spatial-grouping duplicate detection exists near junctions. | Implement duplicate signal detection by source ID and spatial grouping near junctions. |
| 6 | ENR-001 | MISSING/FAIL | No enrichment writer records OSM source entity, mapping confidence, or affected XODR element. | Implement enrichment provenance tracking: OSM entity, mapping confidence, affected XODR element per enrichment. |
| 7 | ENR-003 | PARTIAL/FAIL | Enrichment is not globally idempotent — repeated runs duplicate traffic lights and regen way IDs. | Implement idempotent enrichment: deduplication by source ID, deterministic way ID generation. |
| 8 | ENR-004 | MISSING/FAIL | No grounded/inferred/synthetic-debug mode separation exists. | Implement mode separation: grounded, inferred, and synthetic-debug as separate modes with separate artifacts. |
| 9 | ENR-005 | PARTIAL/FAIL | Only inserted counts (and ways_indexed) are reported; requested/matched/updated/rejected/ambiguous counts absent. | Implement full enrichment accounting: requested, matched, inserted, updated, rejected, ambiguous counts. |
| 10 | ELV-002 | MISSING/FAIL | No piecewise vertical profile fitting exists; every road gets exactly one elevation segment. | Implement piecewise vertical profile fitting capable of representing local grade changes. |
| 11 | ELV-005 | MISSING/FAIL | No separation of terrain-following roads from bridges/tunnels/covered roads/layers/embankments/cuttings. | Implement terrain-structure separation: detect and classify bridges, tunnels, covered roads, layers, embankments, cuttings. |
| 12 | ELV-009 | FAIL | Dedicated seam fixer is a docstring-only stub, unreferenced by the pipeline. | Either implement the seam fixer or remove the claim from the release profile. |
| 13 | LLK-001 | CONFLICTING | Submission stage_08 regenerates all junction LaneLinks unconditionally, discarding existing valid links. | Make LaneLink regeneration conditional: preserve existing valid links unless a complete replacement candidate passes. |
| 14 | LLK-003 | PARTIAL/FAIL | Connecting lanes resolve via contactPoint; incoming lanes use fixed last-section assumption. | Implement incoming lane resolution from contact points, not fixed first/last assumptions. |
| 15 | LLK-004 | PARTIAL/FAIL | Lane pairing uses side+sign ordering with type/width filters; no geometry or movement-intent. | Implement geometry-aware lane pairing using travel direction, type, centerline endpoint geometry, and movement intent. |
| 16 | LLK-006 | MISSING/FAIL | No laneLink path crossing/containment validation exists. BLOCKS_PROFILE for junction-to-junction movement. | Implement laneLink path validation: crossing detection, containment checks, movement-intent compatibility. |
| 17 | LLK-007 | FAIL | LaneLink sanitizer is a stub returning unconditional 'ok'; wired into both stage_08 copies. | Either implement real sanitizer checks or remove from release evidence. |
| 18 | TIL-001 | FAIL | Road bounds computed from geometry start points only; curve extrema ignored -> truncation/overshoot at tile seams. | Implement curve-extrema-aware road bounds computation (arc/spiral/paramPoly3 extrema included). |
| 19 | TIL-002 | FAIL | Roads cloned whole but junction context never copied; no tiling policy document exists. | Implement junction context assignment to tiles and document the tiling policy. |
| 20 | TIL-003 | FAIL | Road-contained elements preserved but junction IDs and controllers dropped (junctions=[] in tiles). | Preserve junction IDs, controllers, signals, objects, markings, and profiles in all tiles. |
| 21 | TIL-004 | FAIL | Duplicated road copies not byte-identical (per-tile markers leak into XODR); no ownership metadata. | Remove per-tile internal markers from emitted XODR; add ownership metadata for duplicated roads. |
| 22 | TIL-005 | FAIL | No mechanism prevents cutting junctions/connectors at tile boundaries; junctions absent from both tiles. | Implement junction-cut prevention: ensure junction context extends across tile boundaries. |
| 23 | TIL-006 | FAIL | Adjacency graph is index-derived (straight-line only, arcs ignored); not wired into stage_09. | Implement curve-aware border connection verification and wire tile_gap_evaluator into stage_09. |
| 24 | TIL-009 | FAIL | Release-mode tile-failure blocking not enforced; `UP_ALLOW_TILE_QA_FAIL=1` set by default in `run_full_test.py:129`. | Remove the default `UP_ALLOW_TILE_QA_FAIL=1`; enforce tile failures as hard blocks in release mode. |
| 25 | TOP-001 | FAIL | Authoritative candidate contains 656 dangling road-level links. | Fix or quarantine the 656 dangling links in the authoritative candidate before release. |
| 26 | TOP-006 | FAIL | Required component-count guard not implemented; only an unreachable component counter exists. | Implement a reachable component-count guard that validates road/junction/laneSection counts. |
| 27 | RAB-001 | MISSING/FAIL | Roundabout detection logic not present in the live tree; reconstruction disabled by default. | Implement roundabout detection logic or explicitly document it as out-of-scope for this release. |
| 28 | RAB-002 | MISSING/FAIL | Ring construction/orientation is submission-only and untested. | Either implement and test ring construction/orientation or mark as out-of-scope. |
| 29 | RAB-003 | MISSING/FAIL | Island/chord avoidance not present in the live tree and untested. | Either implement island/chord avoidance or mark as out-of-scope. |
| 30 | RAB-004 | MISSING/FAIL | Entry/exit reachability not present in the live tree and untested. | Either implement entry/exit reachability or mark as out-of-scope. |
| 31 | RAB-006 | PARTIAL/INSUFFICIENT | Raw preservation is the default (reconstruction disabled) but no measurable-better comparison exists. | Implement a measurable comparison between raw and reconstructed roundabouts, or document the decision. |
| 32 | SEM-003 | MISSING/FAIL | Road classification semantics not implemented in the audited canonical tree. | Implement road classification semantics (motorway, trunk, primary, secondary, etc.). |
| 33 | SEM-006 | MISSING/FAIL | SUMO/netconvert element-by-element provenance comparison not implemented; SUMO not currently used. | Either implement SUMO provenance comparison or document SUMO as out-of-scope. |
| 34 | BLD-001 | FAIL | Blender version/hash/log recording exists (partial), but script hash, import/export options, coordinate transforms, and units absent. | Implement complete Blender pipeline metadata recording. |
| 35 | BLD-002 | MISSING/FAIL | No preservation/transformation accounting for hierarchy, names, materials, textures, UVs, normals, bounds. | Implement mesh preservation/transformation tracking for all attributes. |
| 36 | BLD-003 | MISSING/FAIL | No axis/handedness/scale/origin/XODR-alignment validation using control points. | Implement XODR alignment validation using control points for every exported FBX. |
| 37 | BLD-004 | MISSING/FAIL | No splitting of meshes into CARLA semantic categories or stable names. | Implement mesh splitting into CARLA semantic categories with stable naming. |
| 38 | BLD-005 | PARTIAL/FAIL | Only a disabled-by-default road-geometry diagnostic exists; no FBX collision-mesh generation or validation. | Implement collision mesh generation and validation, enabled by default. |
| 39 | BLD-006 | MISSING/FAIL | No FBX re-import verification step exists in the Blender runner; execution also blocked by missing toolchain. | Implement FBX re-import verification (headless Blender second pass) when toolchain is available. |
| 40 | BLD-007 | MISSING/FAIL | Blender/OSM2World output naming is the ambiguous generic `scene.fbx`/`scene.obj`; deterministic map-specific names required. | Implement deterministic map-specific output names; eliminate ambiguous `scene.fbx`. |
| 41 | O2W-003 | MISSING/BLOCKED | No structural OBJ validation (vertices/faces/bounds) exists; only suffix+existence checks; no artifact on disk. | Implement OBJ structural validation (vertex count, face count, bounds, units, origin, axes, vertical range). |
| 42 | O2W-004 | MISSING/BLOCKED | No OBJ<->XODR alignment verification exists and no artifact is available to verify. | Implement OBJ<->XODR alignment verification using control points and map bounds. |
| 43 | PER-002 | FAIL | Depth modality missing; RGB/semseg/LiDAR present but unverified. | Implement depth camera capture and verify all four modalities (RGB, semantic segmentation, depth, LiDAR). |
| 44 | PER-003 | MISSING/INSUFFICIENT | No semantic-tag/geometry verifier exists. | Implement semantic tag verification against visible geometry and blueprint/object categories. |
| 45 | PER-004 | PARTIAL/INSUFFICIENT | Corrupted-PNG check and requeue exist; duplicate-frame and misalignment detection absent, untested. | Implement duplicate-frame detection and temporal misalignment detection. |
| 46 | PER-005 | MISSING/INSUFFICIENT | No train/validation/test split exists; no leakage checker. | Implement route/tile/weather/map-family-based train/val/test split with leakage prevention. |
| 47 | PER-006 | PARTIAL/INSUFFICIENT | Seeds + fixed architecture recorded; dataset hashing absent. | Implement dataset hashing and full preprocessing metadata recording. |
| 48 | PER-007 | PARTIAL/INSUFFICIENT | Implicit separation only; no gate/test exists. | Implement explicit sensor-mechanics vs perception-quality separation gate. |
| 49 | FIN-002 | PARTIAL/CONFLICTING | Only candidate artifact hashed; report files not hashed/verified as part of promotion. | Bind all report hashes to the promotion transaction; verify report integrity at promotion time. |
| 50 | FIN-005 | PARTIAL | `write_failure_bundle` defined but has zero callers; not wired into any release path. | Wire `write_failure_bundle` into every non-successful release path. |
| 51 | FIN-006 | PARTIAL/INSUFFICIENT | No regression module vs last-accepted+baseline; FV09 comparison is report-only from another branch. | Implement a regression comparison module that runs against the last accepted artifact and raw baseline on the current commit. |
| 52 | FIN-007 | PASS/INSUFFICIENT | Deterministic gates raise before advisory LLM; LLM modules are .pyc only; no test exists. | Add a test proving LLM review cannot override deterministic gates. |
| 53 | FIN-009 | PASS/INSUFFICIENT | Observability on/off does not change semantic output by construction; no parity test executed. | Add a parity test proving observability enable/disable does not change XODR output. |
| 54 | CAR-001 | PARTIAL/BLOCKED | Loader and version-recording present; exact-load enforcement is a record-only gate with no runtime enforcement. | Implement exact-load enforcement: reject any map that does not match the pinned XODR/package ID at runtime. |
| 55 | CAR-004 | PARTIAL/BLOCKED | Spawn-point existence checks exist; drivability-from-spawn is not verified by the gate and runner. | Implement drivability verification from spawn points (not just existence). |
| 56 | CAR-005 | MISSING/BLOCKED | No road-class/distributed spawn-point generator and no 500-tick budget exist. | Implement a distributed spawn-point generator with configurable tick budget per representative scenario. |
| 57 | CAR-006 | IMPLEMENTED_INACTIVE/BLOCKED | Tile-scoped actor management exists in source; cannot be executed or proven without CARLA server. | Wire ActorStreamManager into the release pipeline and verify with live CARLA. |
| 58 | CAR-007 | IMPLEMENTED_INACTIVE/BLOCKED | Camera-on-road and visible-vehicle logic present; requires live CARLA to confirm. | Wire camera/visible-vehicle checks into the release pipeline and verify with live CARLA. |
| 59 | CAR-008 | PARTIAL/BLOCKED | Spawner-level seeding via `UP_DETERMINISTIC_SPAWNS`; TM `random.choice` unseeded; flag off by default. | Seed TrafficManager's `random.choice` and make deterministic TM the default in release profiles. |
| 60 | CAR-009 | VERIFIED_ACTIVE/BLOCKED | Comprehensive defensive cleanup exists; end-to-end teardown verification requires live CARLA. | Add end-to-end teardown verification with live CARLA (actor count == 0 after stage end). |
| 61 | CAR-010 | PASS/IMPORT | Crash classification works for defined CARLA patterns; dead categories (junction/lane-width/link) only in SUMO rules. | Extend crash classifier to cover junction/lane-width/link patterns; verify with live CARLA. |
| 62 | CAR-011 | FAIL | Route completion not verified (movement-only smoke); lane-invasion detection absent; spawn existence recorded as drivability. | Implement route completion verification, lane-invasion detection, and separate spawn-existence from drivability. |
| 63 | SEN-003 | FAIL | Intrinsics (K/K_undist/D), extrinsics (cTv/vTl), attachment pose and resolution ARE recorded but sensor_tick, FOV, blueprint attributes absent from calibration. | Record sensor_tick, FOV, and blueprint attributes in the calibration file. |
| 64 | SEN-004 | IMPLEMENTED_UNVERIFIED/BLOCKED | Sync-mode machinery exists and is deferred correctly on paper; single-tick-owner exclusivity untested without server. | Verify single-tick-owner exclusivity with live CARLA in synchronous mode. |
| 65 | SEN-005 | PARTIAL/BLOCKED | RGB + semseg + LiDAR machinery present (runtime-unverified); depth collection does not exist. | Implement depth camera and verify all four modalities with live CARLA. |
| 66 | SEN-006 | IMPLEMENTED_UNVERIFIED/BLOCKED | wait-for-first-sample helper unit-tested (19/19 bundle subset); live callback stability and frame-coupling untested. | Verify callback stability and frame-coupling with live CARLA. |
| 67 | SEN-007 | PARTIAL/INSUFFICIENT | Vehicle pose, weather, map-id recorded; route progress absent. | Record route progress per frame alongside vehicle pose, weather, map identity, and sensor metadata. |
| 68 | SAN-007 | CONFLICTING | Sanitizer API writes separate output and never overwrites raw input (verified), but no active stage or config invokes it. | Wire the sanitizer into an active pipeline stage or remove the claim from the release profile. |
| 69 | SAN-001..005 | IMPLEMENTED_INACTIVE | Sanitizer rejects malformed XML, preserves element IDs, prohibits deletion, is byte-deterministic, and is idempotent — but the calling stage is absent from the root tree. | Wire the sanitizer into the active release pipeline stage. |
| 70 | SEM-001 | IMPLEMENTED_INACTIVE | Georeference parsing/normalization implemented, canonical tests pass, authoritative candidate's EPSG:32632 georeference verified — but the calling stage is absent from the root tree. | Wire georeference handling into the active release pipeline. |
| 71 | TOP-003 | IMPLEMENTED_INACTIVE/PASS | Straight-line/nearest-attachment fallback blocked by default and by release profiles; canonical test proves ambiguity rejection. | Keep as-is; fallback is correctly blocked by default. |
| 72 | TOP-007 | IMPLEMENTED_INACTIVE | All junction connections on authoritative candidate reference existing roads (0 violations); detection/repair tooling exists but inactive. | Wire junction-connection validation into the active release pipeline. |
| 73 | FRZ-002 | FAIL | Fingerprint comparison is implemented but self-inconsistent by construction (mismatch cannot raise). | Fix the fingerprint comparison to actually raise on mismatch; or remove the claim. |
| 74 | FRZ-001 | PARTIAL/INSUFFICIENT | Freeze manifest is only partially implemented (hash+paths only, no inventories). | Implement complete freeze manifest: hashes, inventories, and provenance for every artifact. |
| 75 | FRZ-003 | PARTIAL/INSUFFICIENT | Freeze attribute gate exists for elevation/lanes ordering, but downstream artifact invalidation (tiling, QA) untested. | Test downstream artifact invalidation when freeze attributes change. |
| 76 | GEO-007 | PARTIAL/INSUFFICIENT | No repairs occur by default (governed mode), so vacuously safe in release mode, but no repair path exists. | Either implement a repair path for geometry issues or document the governed-mode behavior as the policy. |
| 77 | GEO-010 | FAIL | Quarantine implementation not present in the live tree; import broken by construction. | Fix the broken import in `stage_06_links.py:501` or implement the quarantine path. |
| 78 | JCT-003 | FAIL | No lane-center alignment implementation found; connectors fitted to road reference-line endpoints. | Implement lane-center alignment for junction connectors. |
| 79 | JCT-004 | FAIL | No validation that rebuilt connectors avoid self-intersection, unrelated roads, or roundabout islands. | Implement connector validation: self-intersection check, unrelated-road check, roundabout-island check. |
| 80 | JCT-007 | FAIL | No invalidation/remapping of lane sections, offsets, elevation, superelevation, crossfall, signals, controllers after junction rebuild. | Implement post-rebuild invalidation/remapping of all affected road elements. |
| 81 | JCT-006 | CONFLICTING | Deep-copy + revert exists for planView and blocked path preserves original; atomic commit is partial (planView only, not complete road). | Extend atomic commit to cover the complete road (planView + elevation + lanes + links), not just planView. |
| 82 | JCT-008 | CONFLICTING | Numeric before/after evidence and unresolved marking implemented and unit-tested; before/after overlay not produced. | Produce before/after overlay evidence for junction connector rebuild. |
| 83 | DG-001 | PASS/CONFLICTING | Hash separation verified for release vs working artifacts, but no enforcement code exists. | Implement enforcement: reject any artifact that does not have a distinct release vs working hash. |
| 84 | DG-002 | PASS/CONFLICTING | Addendum documents run_11 boundaries, but `generate_gap_figures.py` patches `full_report.json` in place. | Fix `generate_gap_figures.py` to not patch `full_report.json` in place; use immutable output. |
| 85 | DG-005 | PASS/CONFLICTING | Documentation explicitly separates coverage/scope, but no computed attribution exists. | Implement computed attribution: separate coverage/scope differences from implementation-induced defects programmatically. |
| 86 | DG-007 | PASS/CONFLICTING | Perception results explicitly bounded on Town10HD, but no generated-map route data exists. | Generate route data on the generated map for perception claims, or explicitly bound all perception evidence to Town10HD. |
| 87 | DG-008 | PASS/CONFLICTING | Seeds + CI recorded for RQ2 statistical test; no multiple-comparison policy, CI not recomputable offline. | Implement a multiple-comparison policy and make CI recomputable from the recorded seeds. |
| 88 | FIN-010 | INSUFFICIENT | FV09 report states highest maturity + blocked levels but was generated on an older branch; not regenerated on dac6930a. | Regenerate the final status report on the current commit (dac6930a). |
| 89 | REP-001 | FAIL | No single canonical production entry point; entrypoint ambiguity blocks release. | Declare one canonical production entry point and one release configuration. |
| 90 | REP-002 | FAIL | Import cycle between `main_pipeline.py` and stage modules not isolated. | Eliminate or isolate the import cycle. |
| 91 | REP-004 | FAIL | Not all production modules import; core pipeline module is broken (root tree). | Fix the root tree import path so all production modules import without side effects. |
| 92 | REP-006 | PASS/INSUFFICIENT | No pass/docstring-only stubs in release paths; single pass is an intentional abstract base. | Verify the abstract base is intentionally abstract and not a missing implementation. |
| 93 | BOOT-001 | FAIL | Register exists and is well-formed but omits required origin and acquisition date fields. | Add origin and acquisition date fields to the bootstrap manifest. |
| 94 | PREF-002 | BLOCKED | CARLA version/compatibility probe implemented but inactive; cannot be executed. | Wire the CARLA version/compatibility probe into the active release pipeline. |
| 95 | PREF-003 | BLOCKED | Port/process/shutdown verification implemented in snapshot only; execution blocked by missing CARLA. | Wire port/process/shutdown verification into the active release pipeline. |
| 96 | GATE-005 | PASS/SOURCE_ONLY | Gate-layer validators read-only, no autofix imports; caveat on check_*/repair modules mixing mutation elsewhere. | Audit all check_*/repair modules for mutation outside the gate layer; enforce read-only at the gate boundary. |
| 97 | LAN-001 | PARTIAL | s-ordering consistently applied; duplicate-s detection and [0,length] coverage validation absent. | Implement duplicate-s detection and [0, road.length] coverage validation for lane sections. |
| 98 | LAN-012 | PASS/PARTIAL | s-range invariants for superelevation/crossfall active; value-range bounds checked; partial scope only. | Extend superelevation/crossfall validation to cover all s-range invariants. |
| 99 | O2W-001 | PASS | OSM2World outputs consistently classified supplemental/optional (never authoritative) across all code paths. | Keep as-is; this is correctly classified. |
| 100 | O2W-002 | PASS | Cache key includes OSM hash, config hash, OSM2World version, Java version, runner version, CLI arguments, and output format. | Keep as-is; this is correctly implemented. |
| 101 | O2W-005 | PASS/POLICY | With OSM2World disabled by default, all current documentation and manifests classify it as supplemental. | Keep as-is; this is correctly classified as supplemental. |

---

## P1 — Profile-Blocking (blocks specific profiles after P0 resolved)

| # | ID | Current Status | Issue | Required Action |
|---|---|---|---|---|
| 102 | CAR-002 | PASS/UNIT | Guarded map name resolution and town-fallback rejection unit-tested; campaign id `get_map_type='unknown'`. | Resolve the `get_map_type='unknown'` issue so the campaign map type is correctly recorded. |
| 103 | CAR-008 | PARTIAL/BLOCKED | Spawner-level seeding via `UP_DETERMINISTIC_SPAWNS`; TM `random.choice` unseeded; flag off by default. | Seed TrafficManager's `random.choice` and enable deterministic TM by default in release profiles. |
| 104 | CAR-009 | VERIFIED_ACTIVE/BLOCKED | Comprehensive defensive destroy paths exist; end-to-end teardown verification requires live CARLA. | Add end-to-end teardown verification with live CARLA (actor count == 0 after stage end). |
| 105 | DG-004 | INSUFFICIENT | Coverage + CI present in released run_11 evidence set but runner code path does not emit them. | Wire coverage + CI emission into the current runner code path. |
| 106 | DG-009 | INSUFFICIENT | Script + figures present but `domain_gap_results/` inputs missing; script patches `full_report.json` in place. | Fix the in-place patching; ensure `domain_gap_results/` inputs are present and immutable. |
| 107 | FIN-003 | PARTIAL | Fail-closed matrix exists; no stale/placeholder/report-only evidence provenance classification. | Implement provenance classification for all reports (stale, placeholder, report-only, current). |
| 108 | GEO-004 | PASS/IMPLEMENTED_INACTIVE | Heading-only smoothing exists but inactive by default and locked behind unsafe flags. | Keep as-is; inactive by design for release profiles. |
| 109 | GEO-009 | PASS | Geometry-frozen assertions fire at STEP 7 and STEP 8 after elevation acceptance; planView mutation prevented. | Keep as-is; this gate is correctly implemented. |
| 110 | JCT-001 | PASS/UNIT | Anchor/pose resolution implemented and unit-tested (start=end poses via contactPoint paths). | Keep as-is; this gate is correctly implemented. |
| 111 | JCT-002 | PASS/UNIT | Arc-fit candidate enforces start pose/tangent and end position; end-tangent verified via arc geometry. | Keep as-is; this gate is correctly implemented. |
| 112 | JCT-005 | PASS/UNIT | Fallback blocked by default and original preserved with unresolved marker; negative control passes. | Keep as-is; this gate is correctly implemented. |
| 113 | LAN-006 | PASS | Existing valid lane structure preserved by default; no destructive lane operations. | Keep as-is; this gate is correctly implemented. |
| 114 | LAN-010 | PASS | Cross-section repair is id-matching only and preserves center + lane semantics; inactive on default pipeline path. | Keep as-is; inactive by design for release profiles. |
| 115 | OSM-002 | PASS/FIXTURE | Exact OSM hash and extraction bounds durably recorded in campaign manifest. | Keep as-is; this gate is correctly implemented. |
| 116 | OSM-007 | PASS/FIXTURE | Unmodified raw converter outputs preserved with verified hashes and conversion status; gold baseline intact. | Keep as-is; this gate is correctly implemented. |
| 117 | OSM-008 | PASS | Raw-output inventory recorded in manifest and every checkable count independently re-verified. | Keep as-is; this gate is correctly implemented. |
| 118 | PER-001 | PASS/UNIT | Town-fallback detection logic plus canonical negative control prove rejection polarity. | Keep as-is; this gate is correctly implemented. |
| 119 | PER-008 | PASS/UNIT | Import guards exist and canonical suite passes with optional deps present; deps-absent case untested but structurally sound. | Keep as-is; this gate is correctly implemented. |
| 120 | REP-005 | PASS | All pytest collection completes with zero collection errors. | Keep as-is; this gate is correctly implemented. |
| 121 | REP-008 | PASS | Project verification command runs successfully from a clean environment. | Keep as-is; this gate is correctly implemented. |
| 122 | SAN-004 | PASS/UNIT | Sanitizer is byte-deterministic for fixed input (executed probe). | Keep as-is; this gate is correctly implemented. |
| 123 | SAN-005 | PASS/UNIT | Sanitizer is idempotent on executed fixture (second pass byte-identical, zero fixes). | Keep as-is; this gate is correctly implemented. |
| 124 | SEM-001 | PASS/FIXTURE | Georeference parsing/normalization implemented, canonical tests pass, authoritative candidate's EPSG:32632 georeference verified. | Keep as-is; this gate is correctly implemented. |
| 125 | SEM-005 | PASS | The one ambiguity path (displaced connector reconstruction) refuses to guess by default (executed probe). | Keep as-is; this gate is correctly implemented. |
| 126 | SEM-007 | PASS | Executed full-map diagnostic gate is read-only (input hash unchanged, exit 2 on findings); diagnostic-mode correctly gated. | Keep as-is; this gate is correctly implemented. |
| 127 | TIL-007 | PASS/FIXTURE | Tiling is deterministic and order-independent (verified by double-run byte-identical hashes). | Keep as-is; this gate is correctly implemented. |
| 128 | TQA-004 | PASS/FULL_MAP_OFFLINE | Drivable-surface hole/seam/drop/dead-connection scan active and clean on pinned XODR. | Keep as-is; this gate is correctly implemented. |
| 129 | FRZ-004 | PASS/UNIT | Release profiles reject unsafe flags by policy and tests assert this; freeze cannot be silently bypassed. | Keep as-is; this gate is correctly implemented. |
| 130 | GEO-001 | PASS/UNIT | Canonical evaluator (repo-root opendrive_geometry) is live and unit-tested (2827 passed); STRICT runs. | Keep as-is; this gate is correctly implemented. |
| 131 | GEO-003 | PASS/UNIT | Continuity checker is live and unit-tested (24+ migration tests pass); strict gates can be enabled via env var. | Keep as-is; this gate is correctly implemented. |
| 132 | GEO-006 | PASS/FIXTURE | Freeze-before-elevation assertions fire (10 containment tests pass). | Keep as-is; this gate is correctly implemented. |
| 133 | GEO-008 | PASS/FIXTURE | Freeze-before-elevation assertions fire (10 tests pass). | Keep as-is; this gate is correctly implemented. |
| 134 | JCT-006 | CONFLICTING | Deep-copy + revert exists for planView and blocked path preserves original; atomic commit is partial (planView only). | Extend atomic commit to cover the complete road (planView + elevation + lanes + links). |
| 135 | JCT-008 | CONFLICTING | Numeric before/after evidence and unresolved marking implemented and unit-tested; before/after overlay not produced. | Produce before/after overlay evidence for junction connector rebuild. |

---

## Polyline-Specific Issues (All Severities)

| # | File | Lines | Issue | Severity | Fix |
|---|---|---|---|---|---|
| P1 | `geometry/geometry_math.py` | 19-50 | No duplicate-s or monotonicity guard in paramPoly3 sampling | HIGH | Add validation: reject duplicate t values, enforce t in [0,1], sort and deduplicate output points |
| P2 | `geometry/geometry_math.py` | 19-50 | No zero-length segment guard | HIGH | Add check: if length <= 0, raise ValueError or return empty polyline |
| P3 | `geometry/geometry_math.py` | 19-50 | No curve extrema handling (du/dp = 0 or dv/dp = 0 never computed) | HIGH | Compute du/dp and dv/dp polynomials; sample at extrema and include in output |
| P4 | `geometry/geometry_math.py` | 43-49 | No t-value range validation (t > 1 extrapolates beyond geometry) | MEDIUM | Clamp t to [0,1] or raise ValueError |
| P5 | `geometry/geometry_math.py` | callers | Coarse sampling (3-5 points) in all callers | HIGH | Increase sampling density; add adaptive sampling based on curvature |
| P6 | `geometry/geometry_math.py` | 98 | `get_endpoint()` drops paramPoly3 to line approximation | MEDIUM | Implement proper paramPoly3 endpoint evaluation using polynomial |
| P7 | `geometry/planview_smoother.py` | 134 | `_geom_type()` does not recognize paramPoly3 (classifies as line) | HIGH | Add `if g.find("paramPoly3") is not None: return "paramPoly3"` |
| P8 | `geometry/planview_smoother.py` | 341 | `merge_short_segments()` has no type-awareness | HIGH | Add geometry-type check; never merge paramPoly3 into line |
| P9 | `geometry/planview_smoother.py` | 13-29 | `_line_end_xy()` returns None for paramPoly3, bypassing spatial guards | HIGH | Add paramPoly3 endpoint computation to `_line_end_xy()` |
| P10 | `geometry/planview_smoother.py` | 286-288, 465-467 | Zero-length segments silently inflated to 0.001m | MEDIUM | Flag zero-length segments as errors instead of silently inflating |
| P11 | `geometry/planview_smoother.py` | 220 | Heading smoothing modifies interior paramPoly3 base heading, distorting curve shape | MEDIUM | Exclude paramPoly3 geometries from heading smoothing (their heading is defined by polynomial) |
| P12 | `quality/check_geometric_continuity.py` | 225-314 | No duplicate s-value detection in `_parse_geometries()` | HIGH | Add duplicate s0 detection and raise/flag |
| P13 | `quality/check_geometric_continuity.py` | 225-314 | No non-monotonic s detection in `_parse_geometries()` | HIGH | Add monotonicity check after sorting; flag non-monotonic s0 values |
| P14 | `quality/check_geometric_continuity.py` | 225-314 | No zero-length segment detection in `_parse_geometries()` | MEDIUM | Add zero-length geometry detection and flag |
| P15 | `quality/check_geometric_continuity.py` | 683-697 | paramPoly3 continuity check is C0 only (no C1/C2 derivative check) | HIGH | Add C1 (tangent) and C2 (curvature) continuity checks for paramPoly3 segments |
| P16 | `quality/check_geometric_continuity.py` | 199-200 | `_pose_param_poly3()` heading fallback at extrema uses `hdg0` (wrong) | HIGH | At extrema (du/dp=0 and dv/dp=0), carry forward the approaching heading instead of using hdg0 |
| P17 | `quality/check_geometric_continuity.py` | 120-149 | Spiral integration uses first-order Euler with step-size bias | MEDIUM | Use higher-order integration (e.g., RK4) or update heading before position step |

---

## Systemic Issues (Cross-Cutting)

| # | Issue | Severity | Fix |
|---|---|---|---|
| S1 | Root `ultimate_pipeline/main_pipeline.py` cannot import (SYS-001) | CRITICAL | Declare the release tree; make root tree importable |
| S2 | 16+ quality modules imported by `main_pipeline.py` do not exist in active `ultimate_pipeline/quality/` | CRITICAL | Either move the modules to the active quality directory or create re-export shims |
| S3 | 5 pipeline stages missing from active directory (stage_07, stage_09, stage_10, stage_11, stage_12) | CRITICAL | Either implement the stages or document them as out-of-scope |
| S4 | `stage_08_final_integrity.py` is dead code (complete copy of stage_08_integrity.py) | HIGH | Remove the dead copy or merge it into the active stage |
| S5 | No signal/controller validation in final integrity | HIGH | Add signal/controller validation to stage_08_integrity.py |
| S6 | LaneLink regeneration disabled by default | HIGH | Enable LaneLink regeneration in release profiles or document the decision |
| S7 | Broken lanes silently downgraded to `type=none` | HIGH | Make the downgrade explicit (warning + user confirmation) or fail the pipeline |
| S8 | Elevation validation non-strict by default | MEDIUM | Make elevation validation strict by default in release profiles |
| S9 | Duplicate code between stage_08_final_integrity.py and stage_08_integrity.py | MEDIUM | Consolidate into a single shared module |
| S10 | Polyline sampling is lossy by design (3-5 points, no extrema, no guards) | CRITICAL | Implement proper polyline sampling with extrema computation, monotonicity guards, and adaptive density |
