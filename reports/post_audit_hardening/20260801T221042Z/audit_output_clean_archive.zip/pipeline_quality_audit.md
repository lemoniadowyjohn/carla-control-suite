# Pipeline Quality Audit — Critical Stages & Polylines

**Repository:** `C:\Users\admin\PycharmProjects\gpt4\pythonProject3\carla_-main`
**Commit:** `dac6930a7de1698c4b2a1fe4cfb6deb7f2679fe2`
**Branch:** `integration/governed-map-quality-20260729`
**Date:** 2026-08-01

---

## Executive Summary

The pipeline has **10 systemic quality issues** that affect final map quality, concentrated in three areas:

1. **Polyline/geometry sampling is lossy** — paramPoly3 curves are sampled at only 3–5 points, curve extrema are never computed, and the planview smoother misclassifies paramPoly3 as line (allowing curved segments to be replaced by straight ones).
2. **The active release tree is broken** — 16+ quality modules imported by `main_pipeline.py` do not exist in the active `ultimate_pipeline/quality/` directory; `stage_07_lanes.py`, `stage_09_tiling.py`, `stage_10_tile_qa.py`, `stage_11_simulation.py`, `stage_12_domain_gap.py` are all missing from the active pipeline stages directory.
3. **Final integrity checks are either dead code or gated behind experimental flags** — LaneLink regeneration disabled by default, signal/controller validation absent, broken lanes silently downgraded to `type=none`.

---

## Stage-by-Stage Findings

### Stage 01 — OSM Acquisition & Validation

**Status:** Partially implemented. OSM XML structure validation exists; semantic validation (drivable network non-empty) is missing.

- `OSM-001` (FAIL): The OSM acquisition/validation module layer is entirely absent from the audited commit. Entrypoint cannot be found.
- `OSM-003` (FAIL): No canonical `Osm2OdrSettings` configuration exists — entry points cannot share a canonical configuration.
- `OSM-006` (FAIL): No durable OSM-to-XODR provenance mapping exists.

### Stage 02 — Osm2Odr Conversion

**Status:** Raw converter outputs preserved as golden baseline; converter version UNKNOWN_UNSOURCED.

- `OSM-007` (PASS): Unmodified raw converter outputs preserved with verified hashes.
- `OSM-008` (PASS): Raw-output inventory verified against pinned XODR (32710 roads, 3646 junctions).
- **Quality issue:** The converter produces traffic lights as `<object>` elements, not native `<signal>/<signalReference>/<controller>/<control>` structures (SIG-001 FAIL). This means the pipeline never emits functional traffic control — signal_count=0 on the pinned artifact.

### Stage 03/04 — Geometry Processing & Polylines (CRITICAL)

**This is the most polyline-sensitive stage.** Key files:
- `ultimate_pipeline/geometry/geometry_math.py`
- `ultimate_pipeline/geometry/planview_smoother.py`
- `ultimate_pipeline/quality/check_geometric_continuity.py`

#### Polyline-Specific Quality Issues

**1. No duplicate-s or monotonicity guard in paramPoly3 sampling** (`geometry_math.py` lines 19–50)
The `_sample_parampoly3_impl` function accepts any `t_values` iterable and samples at those values without checking for duplicates, monotonicity, or range `[0,1]`. If a caller passes non-monotonic or duplicate t values, the resulting polyline will have duplicate or non-monotonic s-values. No validation or deduplication exists.

**2. No zero-length segment guard** (`geometry_math.py` lines 19–50)
If `length <= 0`, then `p_max = 0.0`, and all sampled points collapse to `(x0, y0)`. The function produces a zero-length polyline with no warning. No check for `length <= 0` exists.

**3. No curve extrema handling** (`geometry_math.py` lines 19–50)
The function samples at fixed t values provided by callers but does not compute or include curve extrema (where du/dp = 0 or dv/dp = 0). For paramPoly3 curves with inflection points or cusps, the sampled polyline can miss the true shape of the curve, especially for spiral entry/exit transitions. The derivative `du/dp = b_u + 2*c_u*p + 3*d_u*p^2` and `dv/dp = b_v + 2*c_v*p + 3*d_v*p^2` are never computed or used.

**4. No t-value range validation** (`geometry_math.py` lines 43–49)
The function computes `p = p_max * float(t)` without clamping or validating that `t` is in `[0, 1]`. If a caller passes `t > 1`, the polynomial is evaluated beyond the geometry's extent, producing extrapolated points outside the road segment.

**5. Coarse sampling in all callers** — paramPoly3 curves are sampled at only 3–5 points:
- `elevation_gap.py` line 169: `t_values = (0.0, 0.5, 1.0)` — only 3 sample points
- `geo_alignment.py` line 42: `t_values = (0.0, 0.5, 1.0)` — same 3-point sampling
- `topology_repair.py` line 69: `sample_parampoly3_points(geom, ..., [1.0])` — only endpoint, no shape
- `xodr_cropper_gps.py` (submission): `parampoly3_t = (0.0, 0.25, 0.5, 0.75, 1.0)` — 5 points, still coarse

None of these callers compute curve extrema to ensure critical shape features are captured.

**6. `GeometryCalculator.get_endpoint()` drops paramPoly3** (`geometry_math.py` line 98)
`else: return GeometryCalculator._integrate_line(x, y, hdg, length)` — spirals and paramPoly3 geometries are treated as straight lines for endpoint computation. This is acknowledged in the docstring but is a known source of geometric error for curved geometries.

**7. `PlanViewSmoother._geom_type()` does not recognize paramPoly3** (`planview_smoother.py` line 134)
```python
if g.find("poly3") is not None:
    return "poly3"
return "line"
```
There is no check for `paramPoly3`. A `<paramPoly3>` geometry is classified as `"line"`. This causes two downstream problems:
- In `merge_small_geometries()` (line 293–295), a paramPoly3 adjacent to a line is considered `same_type=True`, so the paramPoly3 could be merged into the line, destroying the curve shape.
- In `merge_small_geometries()`, the `_line_end_xy()` helper returns `None` for paramPoly3 geometries, so the spatial gap check is bypassed (line 306), allowing merges across spatial discontinuities for paramPoly3 segments.

**8. `merge_short_segments()` has no type-awareness** (`planview_smoother.py` line 341)
This method merges any short segment into its predecessor regardless of geometry type (line/arc/spiral/poly3/paramPoly3). A short paramPoly3 segment merged into a preceding line would replace a curved segment with a straight one, distorting the road shape.

**9. `_line_end_xy()` returns None for paramPoly3** (`planview_smoother.py` lines 13–29)
The function only handles `<line>` child elements. For paramPoly3 geometries, it returns `None`, which causes the spatial gap guard in `merge_small_geometries()` (line 306) and `merge_short_segments()` (line 399–408) to be bypassed. This means paramPoly3 segments can be merged across spatial discontinuities without the anchor-protection guard.

**10. Zero-length segments silently inflated to 0.001m** (`planview_smoother.py` lines 286–288, 465–467)
```python
if length <= 0.0:
    length = 0.001
    g.set("length", f"{length:.6f}")
```
Both `merge_small_geometries()` and `recompute_s_values()` silently change zero-length geometries to 1mm instead of flagging them as errors. This introduces a non-zero-length segment where there should be none, affecting downstream s-value computations and road length calculations.

**11. Heading smoothing modifies interior geometry headings** (`planview_smoother.py` line 220)
Interior geometries with heading jumps are smoothed by averaging. This can distort the shape of paramPoly3 curves whose heading is defined by their polynomial coefficients, not by the `hdg` attribute. For paramPoly3 geometries, the `hdg` attribute is the base heading; the actual heading varies along the curve according to the polynomial derivative. Smoothing the base heading changes the curve shape.

#### Geometric Continuity Checker Issues

**12. No duplicate s-value detection** (`check_geometric_continuity.py` lines 225–314)
`_parse_geometries()` sorts geometries by `s0` but never checks for duplicate s-values. Two geometries with the same `s` value would overlap in the s-domain, and `_pose_at_s()` would select the last one matching `g.s0 <= s_abs`, silently producing incorrect results.

**13. No non-monotonic s detection** (`check_geometric_continuity.py` lines 225–314)
`_parse_geometries()` sorts by `s0` but does not verify that `s0` values are strictly increasing. If the input XML has non-monotonic s-values, the sort fixes the order but the gap is silently ignored.

**14. No zero-length segment detection** (`check_geometric_continuity.py` lines 225–314)
`_parse_geometries()` does not check for zero-length geometries. A zero-length geometry would produce a zero-length segment in the planView, and `_pose_at_s()` would clamp `s_local` to `max(g_sel.length, 0.0) = 0`, always returning the start pose silently.

**15. paramPoly3 continuity check is C0 only** (`check_geometric_continuity.py` lines 683–697)
The continuity check compares endpoint poses using Euclidean distance and heading difference. This is C0 (position) and heading continuity only. It does NOT check C1 (tangent/derivative) or C2 (curvature) continuity for paramPoly3 segments.

**16. `_pose_param_poly3()` heading fallback at extrema is wrong** (`check_geometric_continuity.py` lines 199–200)
```python
if abs(du_dp) < 1e-12 and abs(dv_dp) < 1e-12:
    hdg = g.hdg0
```
At a paramPoly3 curve extremum (where du/dp = 0 and dv/dp = 0), the heading is set to the base heading `hdg0`. This is incorrect — at an extremum, the tangent direction is singular and should be handled as a discontinuity or carried forward from the approaching direction. Using `hdg0` can produce a sudden heading jump at curve extrema.

**17. Spiral integration has step-size bias** (`check_geometric_continuity.py` lines 120–149)
The spiral numerical integration uses a fixed step size `ds=0.2` and updates heading using the midpoint curvature `k_mid`, but then uses the *old* heading `hdg` (not `hdg_mid`) for the position integration step. This is a first-order Euler integration that introduces systematic error, especially for long spirals.

### Stage 05 — Elevation & DEM

**Status:** Elevation frozen before geometry processing; flat fallback when DEM is invalid/missing.

- `ELV-002` (FAIL): No piecewise vertical profile fitting exists; every road gets exactly one elevation segment.
- `ELV-005` (FAIL): No separation of terrain-following roads from bridges/tunnels/covered roads/layers/embankments/cuttings.
- `ELV-009` (FAIL): Dedicated seam fixer is a docstring-only stub, unreferenced by the pipeline.
- `DEM-005` (CONFLICTING): Flat/median/hardcoded fallbacks are fail-closed in strict mode but used as defaults in non-strict mode.
- `Elevation invariants module` (DEAD CODE): `elevation_invariants.py` is not wired into the release pipeline. No intra-segment monotonicity check, no duplicate s-value detection, no zero-length segment detection.

### Stage 06 — Lane Sections, Widths, Offsets

**Status:** Active but with quality gaps.

- `LAN-001` (PARTIAL): s-ordering is consistently applied, but duplicate-s detection and `[0, length]` coverage validation are absent.
- `LAN-010` (PASS, IMPLEMENTED_INACTIVE): Cross-section repair is id-matching only and preserves center + lane semantics; inactive on the default pipeline path.
- `LAN-011` (FAIL): No junction-mouth width bound or connector-width compatibility check exists.

### Stage 07 — Lanes (DEAD CODE)

**`stage_07_lanes.py` does not exist in the active `ultimate_pipeline/pipeline_stages/` directory.** It exists only in `submission/infrastructure/ultimate_pipeline/pipeline_stages/`. The lane generation stage is completely absent from the release pipeline.

### Stage 08 — Integrity & Final Quality Gates

**Status:** `stage_08_integrity.py` is active (906 lines, imported by `main_pipeline.py` at 5 points). `stage_08_final_integrity.py` is dead code (736 lines, never imported).

**Critical quality gaps in the active integrity stage:**

1. **No signal/controller validation.** Neither `stage_08_integrity.py` nor `stage_08_final_integrity.py` validates signal or controller integrity. Signals are only dropped (`drop_signals=True`) during spawn validation, never validated.
2. **LaneLink regeneration disabled by default.** `_unsafe_lanelink_regen_enabled()` requires both explicit opt-in AND an `experimental_unsafe` release profile. Broken lane links from source data are preserved.
3. **No LaneLink target validation.** No check verifies that LaneLink targets (road/laneSection/lane triples) actually exist in the map.
4. **Broken lanes silently downgraded.** The fallback chain (lines 309–466) silently converts broken driving lanes to `type=none`, degrading map quality without user notification beyond a print statement.
5. **Shapely collision mesh gate is conditional.** If `USE_SHAPELY` is False, the collision mesh gate is entirely skipped.
6. **Elevation validation non-strict by default.** CARLA elevation validation only raises errors in strict mode (`UP_STRICT_QUALITY_GATES=1`), which is off by default.
7. **Duplicate code.** `stage_08_final_integrity.py` is a near-exact copy of `stage_08_integrity.py` step 8 logic, creating a maintenance burden and risk of divergence.

### Stage 09 — Tiling

**Status:** `stage_09_tiling.py` does not exist in the active pipeline stages directory. Tiling code lives only in `submission/infrastructure/`. Stage 9 is dead code in the release pipeline.

**Quality issues in the tiling code (submission only):**
- Road bounds computed from geometry start points only (curve extrema ignored) → truncation/overshoot artifacts at tile seams.
- Roads cloned whole but junction context never copied.
- Duplicated road copies not byte-identical (per-tile markers leak into XODR).
- No junction-cut prevention; boundary junctions appear in neither tile.
- `UP_ALLOW_TILE_QA_FAIL=1` set by default in `run_full_test.py:129` — release-mode tile-failure blocking is not enforced.

### Stage 10 — Tile QA, Screenshots, Visual Defect Coverage

**Status:** `stage_10_tile_qa.py` does not exist in the active pipeline stages directory. Dead code.

- `TQA-004` (PASS FULL_MAP_OFFLINE): Drivable-surface hole/seam/drop/dead-connection scan is active and clean on the pinned XODR.
- `TQA-003` (FAIL): No image-content checks exist; the smoke gate only captures success/failure of screenshot generation, not visual correctness.
- `TQA-005` (BLOCKED): Stress tester and weather controller exist but are default-off, simulation-gated.

### Stage 11 — Exact-Map CARLA Runtime Validation

**Status:** CARLA server unavailable. All runtime requirements BLOCKED.

- `CAR-001` (PARTIAL/BLOCKED): Loader and version-recording are present and offline-importable; exact-load enforcement is a record-only gate with no runtime enforcement.
- `CAR-011` (FAIL): Route completion is not verified (movement-only smoke), lane-invasion detection is absent, and spawn existence is recorded as drivability.

### Stage 12 — Domain Gap Analysis

**Status:** `stage_12_domain_gap.py` does not exist in the active pipeline stages directory. Dead code.

- `DG-009` (INSUFFICIENT_EVIDENCE): Script + figures present but `domain_gap_results/` inputs missing; script also patches `full_report.json` in place.

### Stage 13 — OSM2World / Blender / Visual Assets

**Status:** OSM2World never executed (policy). Blender pipeline absent.

- `BLD-001` (FAIL): Version/hash/log recording exists (partial), but script hash, import/export options, coordinate transforms, and units are absent.
- `BLD-002` (FAIL): No preservation/transformation accounting for hierarchy, names, materials, textures, UVs, normals, or bounds.
- `BLD-003` (FAIL): No axis/handedness/scale/origin/XODR-alignment validation using control points exists.
- `BLD-004` (FAIL): No splitting of meshes into CARLA semantic categories or stable names in the Blender/FBX pipeline.
- `BLD-005` (FAIL): Only a disabled-by-default road-geometry diagnostic exists; no FBX collision-mesh generation or validation.
- `BLD-006` (FAIL): No FBX re-import verification step exists in the Blender runner; execution also blocked by missing toolchain.
- `BLD-007` (FAIL): Blender/OSM2World output naming is the ambiguous generic `scene.fbx`/`scene.obj`; the requirement for deterministic map-specific output names is unmet.
- `O2W-003` (FAIL): No structural OBJ validation (vertices/faces/bounds) exists; only suffix+existence checks; no artifact on disk.
- `O2W-004` (FAIL): No OBJ↔XODR alignment verification exists and no artifact is available to verify.

### Stage 14 — Unreal Import & Cooking

**Status:** BLOCKED_TOOLCHAIN. No UE4.26 source build on host. Packaged `E:\CARLA\CARLA_0.9.16` cannot cook. Host F: drive has 111.7 GB free (needs ≥200 GB).

### Stage 15 — CARLA Runtime Validation

**Status:** CARLA wheel 0.9.16 imports successfully; no server on localhost:2000.

- `CAR-002` (PASS UNIT): Guarded map name resolution and town-fallback rejection are unit-tested and active.
- `CAR-003` (PASS UNIT): Town-fallback is deterministic, per-map-ID, and never silent; verified by canonical unit tests.
- `CAR-010` (PASS IMPORT): Crash classification works for its defined CARLA patterns (6/6 synthetic positives).
- `CAR-011` (FAIL): Route completion is not verified (movement-only smoke), lane-invasion detection is absent, and spawn existence is recorded as drivability.

---

## Polyline-Specific Summary

| Issue | File | Lines | Severity |
|---|---|---|---|
| No duplicate-s/monotonicity guard in sampling | `geometry_math.py` | 19–50 | HIGH |
| No zero-length segment guard | `geometry_math.py` | 19–50 | HIGH |
| No curve extrema handling | `geometry_math.py` | 19–50 | HIGH |
| No t-value range validation | `geometry_math.py` | 43–49 | MEDIUM |
| Coarse sampling (3–5 points) in all callers | multiple | various | HIGH |
| `get_endpoint()` drops paramPoly3 to line | `geometry_math.py` | 98 | MEDIUM |
| `_geom_type()` misclassifies paramPoly3 as line | `planview_smoother.py` | 134 | HIGH |
| `merge_short_segments()` has no type-awareness | `planview_smoother.py` | 341 | HIGH |
| `_line_end_xy()` returns None for paramPoly3 | `planview_smoother.py` | 13–29 | HIGH |
| Zero-length segments silently inflated to 0.001m | `planview_smoother.py` | 286–288, 465–467 | MEDIUM |
| Heading smoothing distorts paramPoly3 curves | `planview_smoother.py` | 220 | MEDIUM |
| No duplicate s-value detection in continuity checker | `check_geometric_continuity.py` | 225–314 | HIGH |
| No non-monotonic s detection | `check_geometric_continuity.py` | 225–314 | HIGH |
| No zero-length segment detection | `check_geometric_continuity.py` | 225–314 | MEDIUM |
| paramPoly3 continuity is C0 only | `check_geometric_continuity.py` | 683–697 | HIGH |
| Heading fallback at extrema is wrong | `check_geometric_continuity.py` | 199–200 | HIGH |
| Spiral integration has step-size bias | `check_geometric_continuity.py` | 120–149 | MEDIUM |

---

## Systemic Issues

1. **Broken release tree (SYS-001):** All audited behavior lives only in `submission/infrastructure/ultimate_pipeline`. The root `ultimate_pipeline/main_pipeline.py` cannot import (`ModuleNotFoundError: ultimate_pipeline.bootstrap_repo_root`; ~20 missing modules). No policy declares the release tree.

2. **16+ missing quality modules:** `main_pipeline.py` imports from `ultimate_pipeline/quality/` modules that do not exist in the active directory (quality_gate_manager, check_xml_integrity, check_physics_feasibility, check_randomness_entropy, check_semantic_overlap, collision_mesh, check_lane_section_successors, check_xodr_schema, check_lane_connectivity, check_lane_link_targets_exist, carla_pruner, lane_width_invariants, pipeline_health_summary, autofix_postprune_elevation, map_acceptance, quality_gates). All exist in `submission/infrastructure/` only.

3. **Missing pipeline stages:** `stage_07_lanes.py`, `stage_09_tiling.py`, `stage_10_tile_qa.py`, `stage_11_simulation.py`, `stage_12_domain_gap.py` do not exist in the active pipeline stages directory.

4. **Dead code dominance:** `stage_08_final_integrity.py` is a complete copy of step 8 logic never called. `stage_07_lanes.py` and `stage_09_tiling.py` are missing from the active pipeline.

5. **No signal/controller validation in final integrity:** Signals are only dropped (not validated) during spawn validation.

6. **LaneLink regeneration disabled by default:** Broken lane links from source data are preserved.

7. **Broken lanes silently downgraded:** The fallback chain silently converts broken driving lanes to `type=none`.

8. **Elevation validation non-strict by default:** Only raises errors in strict mode (off by default).

9. **Duplicate code:** `stage_08_final_integrity.py` is a near-exact copy of `stage_08_integrity.py`.

10. **Polyline sampling is lossy by design:** paramPoly3 curves sampled at 3–5 points with no extrema computation, no monotonicity guard, no zero-length guard, no t-range validation. The planview smoother misclassifies paramPoly3 as line, allowing curved segments to be replaced by straight ones.