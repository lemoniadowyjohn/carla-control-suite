# Test Quality

## Canonical runner

- `pytest.ini` testpaths: `ultimate_pipeline/tests tests/unit`
- Canonical offline suite: `python -m pytest -m "not carla" -q -p no:cacheprovider` → **336 passed, 0 failed, 0 skipped, ~48 warnings, exit 0** (verified on dac6930a multiple times)
- Non-canonical but executed during audit: `tests/roadrunner/test_gate_matrix.py` (16 passed), `tests/carla_tools/test_session.py` (10 passed), submission-tree tile tests (21 passed / 1 failed), opendrive_geometry migration tests (24 passed), junction connector rebuild tests, 102-test contracts batch

## Test-path coverage limitation

- Tests under `tests/opendrive_geometry`, `tests/topology`, `tests/carla_tools`, `tests/domain_gap`, `tests/roadrunner` are NOT in canonical testpaths; their evidence is supplementary.
- `import ultimate_pipeline.main_pipeline` fails (`bootstrap_repo_root`); no end-to-end import evidence from the root tree (SYS-001).

## Negative controls

- Release-critical validators with executed negative controls: 37 (e.g., GATE stale-hash rejection, promotion atomicity, ELV/LLK/width checkers — reviewer_B ran 3 sensitivity probes proving defect detection)
- PASS claims without executed negative control: 48 pre-review; after Phase 6, remaining PASSes were individually upheld by reviewer_B (45 AGREE, 45/45 PASS claims reviewed = 100%)

## Compilation-only / weak evidence risks

- Some tests exist only as `.pyc` (sources deleted): calibration/hash, ctv inversion, record-route defaults — noted in SEN-003/PER records
- SAN-001..007, SEM-001, TOP-003/007 verified on an executed probe of the sanitizer module but the calling stage is absent from the root tree → IMPLEMENTED_INACTIVE
- `reports\C01_carla_runtime_audit.json` is stale (2026-07-29, different commit) and was NOT used as evidence