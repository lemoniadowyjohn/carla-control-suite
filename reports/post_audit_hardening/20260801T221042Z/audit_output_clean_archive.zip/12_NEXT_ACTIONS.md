# Next Actions

## P0 (release-critical, no profile can pass without them)

1. Declare the release tree and make `ultimate_pipeline/main_pipeline.py` importable end-to-end (SYS-001; REP-001/002/004).
2. Fix elevation profile fitting: implement piecewise vertical profiles (ELV-002), separate terrain-following from structures (ELV-005), replace seam-fixer stub (ELV-009).
3. Repair LaneLink sanitizer (LLK-007 stub returns unconditional 'ok'); make junction LaneLink regeneration conditional on complete replacement candidate (LLK-001).
4. Implement signal layer: emit native <signal>/<controller> structures (SIG-001..005) and make enrichment idempotent (ENR-003).
5. Fix tiling: curve-extrema-aware road bounds (TIL-001), documented assignment policy (TIL-002), preserve junction/controller context (TIL-003), byte-identical duplicates + ownership (TIL-004), junction-cut prevention (TIL-005), remove UP_ALLOW_TILE_QA_FAIL default (TIL-009).
6. Remove or implement quarantine path (GEO-010 broken import) and roundabout subsystem (RAB-001..004).

## P1 (profile-blocking after P0)

1. Provide CARLA 0.9.16 server + UE4.26 toolchain (host action) to unblock CAR-001..011, SEN, PER, TQA, BLD runtime evidence.
2. Implement Blender pipeline (BLD-001..007) and OSM2World OBJ validation/alignment (O2W-003/004).
3. Add depth camera modality (PER-002) and split/leakage checker (PER-005).
4. Fix junction rebuild validation (JCT-003/004/007) and atomic planView commit completeness (JCT-006/008).

## P2 (evidence strengthening)

1. Add negative controls for the remaining 45 PASS claims that lacked them pre-review.
2. Wire tile_gap_evaluator into stage_09 with curve-aware sampling (TIL-006).
3. Add test proving observability on/off does not change semantic output (FIN-009 parity test).
4. Hash-bound report files to promotion transaction (FIN-002).
5. Regenerate FV09/final status report on dac6930a (FIN-010).
