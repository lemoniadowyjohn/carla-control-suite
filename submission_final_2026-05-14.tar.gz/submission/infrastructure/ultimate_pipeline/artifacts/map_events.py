from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

EVENTS_FILENAME = "map_events.jsonl"

# Tests expect event_type + timestamp_utc always present, and treat stage_name as a required field.
REQUIRED_FIELDS = ["event_type", "timestamp_utc", "stage_name"]


def get_required_fields() -> List[str]:
    return list(REQUIRED_FIELDS)


def _now_utc_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def append_map_event(
    run_dir: Union[str, Path],
    event: Dict[str, Any],
    best_effort: bool = True,
) -> Optional[Path]:
    """
    Append an event as JSONL and return the JSONL path on success.

    Contract (unit tests):
      - must create <run_dir>/map_events.jsonl
      - must include REQUIRED_FIELDS in every line (may be None)
      - must return path on success
    """
    try:
        run_dir_p = Path(run_dir)
        run_dir_p.mkdir(parents=True, exist_ok=True)
        out = run_dir_p / EVENTS_FILENAME

        payload = dict(event or {})
        payload.setdefault("event_type", "map_event")
        payload.setdefault("timestamp_utc", _now_utc_iso())
        payload.setdefault("stage_name", payload.get("stage_name", None))

        # Ensure required keys exist even if user didn't provide them
        for key in REQUIRED_FIELDS:
            payload.setdefault(key, None)

        line = json.dumps(payload, sort_keys=True, separators=(",", ":"))
        with out.open("a", encoding="utf-8") as f:
            f.write(line + "\n")
        return out
    except Exception:
        if not best_effort:
            raise
        return None


def read_map_events(run_dir: Union[str, Path]) -> List[Dict[str, Any]]:
    p = Path(run_dir) / EVENTS_FILENAME
    if not p.is_file():
        return []
    out: List[Dict[str, Any]] = []
    for line in p.read_text(encoding="utf-8", errors="replace").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            out.append(json.loads(line))
        except Exception:
            continue
    return out


def log_gate_removal(
    run_dir: Union[str, Path],
    *,
    stage_name: str,
    gate_name: str,
    road_id: str,
    removed_length_m: float,
    **extra: Any,
) -> Optional[Path]:
    # Tests call with these exact kwarg names and expect event_type gate_removal
    return append_map_event(
        run_dir,
        {
            "event_type": "gate_removal",
            "stage_name": stage_name,
            "gate_name": gate_name,
            "road_id": road_id,
            "removed_length_m": removed_length_m,
            **extra,
        },
        best_effort=True,
    )


def log_carla_load_failure(
    run_dir: Union[str, Path],
    *,
    stage_name: str,
    failed_before_masking: bool,
    tile_id: str,
    error_message: str,
    **extra: Any,
) -> Optional[Path]:
    # Tests call without "reason"; they pass failed_before_masking + error_message.
    return append_map_event(
        run_dir,
        {
            "event_type": "carla_load_failure",
            "stage_name": stage_name,
            "carla_failed_before_masking": bool(failed_before_masking),
            "tile_id": tile_id,
            "error_message": error_message,
            **extra,
        },
        best_effort=True,
    )
